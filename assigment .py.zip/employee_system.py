from tkinter import *
import View
import Employee

"""This class creates employee, department and view employee form"""


class employee_system:
    def __init__(self, window):
        self.wn = window
        self.wn.title('Employee system')
        self.wn.geometry("800x700")
        self.wn.config(bg='black')
        self.lb_heading = Label(self.wn, text='Employee Management System', font=('arial', 18, 'bold'), bg='black',
                                fg='magenta')
        self.lb_heading.place(x=0, y=0, relwidth=1)

        self.lb_employee_form = Button(self.wn, text='Employee Form', font=('arial', 12, 'bold'),
                                       command=self.employee_Form, fg='white',
                                       bg='grey', width='25')
        self.lb_employee_form.place(x=200, y=150)

        self.lb_view_Form = Button(self.wn, text='View Employee', font=('arial', 12, 'bold'), command=self.view_Form,
                                   fg='white',
                                   bg='grey', width='25')
        self.lb_view_Form.place(x=400, y=300)

    def employee_Form(self):
        """This function opens the imported employee form"""
        emq = Toplevel(self.wn)
        Employee.Employee(emq)

    def view_Form(self):
        """This function opens the imported view form"""
        abc = Toplevel(self.wn)
        View.View(abc)
